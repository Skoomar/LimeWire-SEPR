package com.rear_admirals.york_pirates.minigame;

import com.rear_admirals.york_pirates.GameTest;
import org.junit.Test;

import static org.junit.Assert.*;

public class MiniGamePlayerTest extends GameTest {

    @Test
    public void isDead() {
        MiniGamePlayer player = new MiniGamePlayer();


    }

    @Test
    public void movable() {

    }

}