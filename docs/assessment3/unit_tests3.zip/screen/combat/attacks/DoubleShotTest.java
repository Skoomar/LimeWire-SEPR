package com.rear_admirals.york_pirates.screen.combat.attacks;

import com.rear_admirals.york_pirates.GameTest;
import org.junit.Test;

import static org.junit.Assert.*;

public class DoubleShotTest extends GameTest {

    @Test
    public void doAttack() {
    }
}