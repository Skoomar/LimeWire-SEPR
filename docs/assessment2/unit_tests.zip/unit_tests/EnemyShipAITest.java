package com.limewire.game.data;

import org.junit.Test;

import java.util.Set;

import static org.junit.Assert.*;

public class EnemyShipAITest {

    @Test
    public void isNearAShip() {
        Map map = new Map("32x32Map.txt");
        EnemyShipAI derwentAI = new EnemyShipAI(new Ship(29, 5, 1, "derwent", 3, 1), map);
        EnemyShipAI vanbrughAI = new EnemyShipAI(new Ship(27, 9, 1, "vanbrugh", 3, 1), map);

        // Check that out of range ships are ignored
        map.setShip(derwentAI.getShip());
        map.setShip(vanbrughAI.getShip());

        assertFalse(derwentAI.isNearAShip());
        assertFalse(vanbrughAI.isNearAShip());

        // Check that ships of the same team are ignored if they are close by
        map.setShip(new Ship(30, 4, 1, "derwent", 3, 1));
        map.setShip(new Ship(28, 10, 1, "vanbrugh", 3, 1));

        assertFalse(derwentAI.isNearAShip());
        assertFalse(vanbrughAI.isNearAShip());

        // Check that close by ships of other teams are detected
        Ship nearDerwentAI = new Ship(28, 3, 1, "james", 3, 1);
        map.setShip(nearDerwentAI);
        assertTrue(derwentAI.isNearAShip());

        Ship nearVanbrughAI = new Ship(30, 9, 1, "derwent", 3, 1);
        map.setShip(nearVanbrughAI);
        assertTrue(vanbrughAI.isNearAShip());

        // Check that coordinates of nearest ship detected are correct
        assertTrue(derwentAI.getNearestShip().equals(nearDerwentAI.getCoords()));
        assertTrue(vanbrughAI.getNearestShip().equals(nearVanbrughAI.getCoords()));
    }

    @Test
    public void moveShip() {
        Map map = new Map("32x32Map.txt");
        EnemyShipAI derwentAI = new EnemyShipAI(new Ship(29, 5, 1, "derwent", 3, 1), map);
        EnemyShipAI vanbrughAI = new EnemyShipAI(new Ship(27, 9, 1, "vanbrugh", 3, 1), map);
        map.setShip(derwentAI.getShip());
        map.setShip(vanbrughAI.getShip());

        Ship nearDerwentAI = new Ship(28, 3, 1, "james", 3, 1);
        Ship nearVanbrughAI = new Ship(30, 9, 1, "derwent", 3, 1);
        map.setShip(nearDerwentAI);
        map.setShip(nearVanbrughAI);

        derwentAI.isNearAShip();
        vanbrughAI.isNearAShip();

        // Check that new coordinates after move are that of the nearest square adjacent to nearest ship
        derwentAI.moveShip();
        assertTrue(derwentAI.getShip().getCoords().equals(new Coords(29, 3))
                || derwentAI.getShip().getCoords().equals(new Coords(30, 4)));

        vanbrughAI.moveShip();
        assertTrue(vanbrughAI.getShip().getCoords().equals(new Coords(29, 9)));
    }

    @Test
    public void randomMove() {
        Map map = new Map("32x32Map.txt");
        EnemyShipAI derwentAI = new EnemyShipAI(new Ship(29, 5, 1, "derwent", 3, 1), map);
        EnemyShipAI vanbrughAI = new EnemyShipAI(new Ship(27, 9, 1, "vanbrugh", 3, 1), map);
        map.setShip(derwentAI.getShip());
        map.setShip(vanbrughAI.getShip());


        Coords[] previousCoords = new Coords[2];
        Set[] possibleMoves = new Set[2];
        boolean repeatCoords = false;
        boolean invalidMove = false;

        for (int m = 0; m < 5; m++) {
            previousCoords[0] = derwentAI.getShip().getCoords();
            previousCoords[1] = vanbrughAI.getShip().getCoords();
            possibleMoves[0] = derwentAI.getPossibleMove();
            possibleMoves[1] = vanbrughAI.getPossibleMove();

            derwentAI.randomMove();
            vanbrughAI.randomMove();

            // Ensure new coordinates are always selected
            if (previousCoords[0].equals(derwentAI.getShip().getCoords()) || previousCoords[1].equals(vanbrughAI.getShip().getCoords())) {
                repeatCoords = true;
                break;
            }

            if (!possibleMoves[0].contains(derwentAI.getShip().getCoords()) || !possibleMoves[1].contains(vanbrughAI.getShip().getCoords())) {
                invalidMove = true;
                break;
            }
        }
        assertFalse(repeatCoords);
        assertFalse(invalidMove);
    }
}