package com.limewire.game.data;

import org.junit.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.*;

public class MapTest {

    @Test
    public void isValidForEnemy() {
        Map map = new Map("/Map/32x32Map.txt");

        // Test coordinates outside the map
        assertFalse(map.isValidForEnemy(new Coords(-1, -1)));
        assertFalse(map.isValidForEnemy(new Coords(2, -3)));
        assertFalse(map.isValidForEnemy(new Coords(-3, 2)));
        assertFalse(map.isValidForEnemy(new Coords(32, 32)));
        assertFalse(map.isValidForEnemy(new Coords(25, 33)));
        assertFalse(map.isValidForEnemy(new Coords(35, 29)));

        // Test coordinates of un-pathable squares in the map (e.g squares of land)
        assertFalse(map.isValidForEnemy(new Coords(2, 1)));
        assertFalse(map.isValidForEnemy(new Coords(4, 8)));
        assertFalse(map.isValidForEnemy(new Coords(27, 21)));
        assertFalse(map.isValidForEnemy(new Coords(15, 27)));

        // Test coordinates of valid squares
        assertTrue(map.isValidForEnemy(new Coords(1, 20)));
        assertTrue(map.isValidForEnemy(new Coords(14, 30)));
        assertTrue(map.isValidForEnemy(new Coords(15, 21)));
        assertTrue(map.isValidForEnemy(new Coords(10, 22)));
    }

    @Test
    public void isValidSquare() {
        Map map = new Map("/Map/32x32Map.txt");

        // Test coordinates outside the map
        assertFalse(map.isValidForEnemy(new Coords(-1, -1)));
        assertFalse(map.isValidForEnemy(new Coords(2, -3)));
        assertFalse(map.isValidForEnemy(new Coords(-3, 2)));
        assertFalse(map.isValidForEnemy(new Coords(32, 32)));
        assertFalse(map.isValidForEnemy(new Coords(25, 33)));
        assertFalse(map.isValidForEnemy(new Coords(35, 29)));

        // Test coordinates of un-pathable squares in the map (e.g squares of land)
        assertFalse(map.isValidForEnemy(new Coords(2, 1)));
        assertFalse(map.isValidForEnemy(new Coords(4, 8)));
        assertFalse(map.isValidForEnemy(new Coords(27, 21)));
        assertFalse(map.isValidForEnemy(new Coords(15, 27)));

        // Test coordinates of ships
        map.setShip(new Ship(29, 5, 1, "derwent", 3, 1));
        map.setShip(new Ship(1, 28, 1, "derwent", 3, 1));
        map.setShip(new Ship(14, 20, 1, "vanbrugh", 3, 1));

        assertFalse(map.isValidForEnemy(new Coords(29, 5)));
        assertFalse(map.isValidForEnemy(new Coords(1, 28)));
        assertFalse(map.isValidForEnemy(new Coords(14, 20)));

        // Test coordinates of valid squares
        assertTrue(map.isValidForEnemy(new Coords(1, 20)));
        assertTrue(map.isValidForEnemy(new Coords(14, 30)));
        assertTrue(map.isValidForEnemy(new Coords(15, 21)));
        assertTrue(map.isValidForEnemy(new Coords(10, 22)));
    }

    // Test a square has not already been visited
    @Test
    public void isNewSquare() {
        Map map = new Map("/Map/32x32Map.txt");

        Set<Coords> visitedSquares = new HashSet<Coords>();
        visitedSquares.add(new Coords(5, 6));
        visitedSquares.add(new Coords(6, 6));
        visitedSquares.add(new Coords(6, 7));

        // Test squares that have been visited already
        assertFalse(map.isNewSquare(visitedSquares, new Coords(5, 6)));
        assertFalse(map.isNewSquare(visitedSquares, new Coords(6, 6)));
        assertFalse(map.isNewSquare(visitedSquares, new Coords(6, 7)));

        // Test squares not already visited
        assertTrue(map.isNewSquare(visitedSquares, new Coords(7, 7)));
        assertTrue(map.isNewSquare(visitedSquares, new Coords(8, 7)));
        assertTrue(map.isNewSquare(visitedSquares, new Coords(7, 10)));
    }

    @Test
    public void getPossibleMoves() {
        Map map = new Map("/Map/32x32Map.txt");

        Ship ship = new Ship(6, 18, 1,"james", 3, 1);
        Set<Coords> expectedPossibleMoves = new HashSet<Coords>();
        expectedPossibleMoves.add(new Coords(4, 12));
        expectedPossibleMoves.add(new Coords(8, 14));
        expectedPossibleMoves.add(new Coords(7, 15));
        expectedPossibleMoves.add(new Coords(6, 15));
        expectedPossibleMoves.add(new Coords(8, 12));
        expectedPossibleMoves.add(new Coords(5, 12));
        expectedPossibleMoves.add(new Coords(5, 15));
        expectedPossibleMoves.add(new Coords(6, 16));
        expectedPossibleMoves.add(new Coords(6, 14));
        expectedPossibleMoves.add(new Coords(6, 12));
        expectedPossibleMoves.add(new Coords(9, 13));
        expectedPossibleMoves.add(new Coords(5, 14));
        expectedPossibleMoves.add(new Coords(7, 13));
        expectedPossibleMoves.add(new Coords(8, 13));
        expectedPossibleMoves.add(new Coords(6, 13));
        expectedPossibleMoves.add(new Coords(7, 14));
        expectedPossibleMoves.add(new Coords(5, 13));

        Set<Coords> testPossibleMoves = map.getPossibleMoves(ship);

        assertTrue(expectedPossibleMoves.size() == testPossibleMoves.size());

        // Check that both sets contain the same moves regardless of order
        // the design of the getPossibleMoves method means the order of the moves may change
        boolean setsMatch = true;
        boolean moveMatches;
        for (Coords testMove : testPossibleMoves) {
            moveMatches = false;
            for (Coords expectedMove : expectedPossibleMoves) {
                if (testMove.equals(expectedMove)) {
                    moveMatches = true;
                }
            }
            if (!moveMatches) {
                setsMatch = false;
                break;
            }
        }
        assertTrue(setsMatch);
    }
}