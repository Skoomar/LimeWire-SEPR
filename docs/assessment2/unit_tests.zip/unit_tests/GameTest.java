package com.limewire.game.data;

import org.junit.Test;

import java.util.Set;

import static org.junit.Assert.*;

public class GameTest {

    @Test
    public void moveSelectedShip() {
        Game game = new Game();
        Ship ship = new Ship(1, 11, 1, "james", 3, 1);

        Coords previousCoords = new Coords(1, 11);

        // Test that ship doesn't move if given out of range coordinates
        game.moveSelectedShip(new Coords(5, 11));
        assertTrue(ship.getCoords().equals(previousCoords));

        game.moveSelectedShip(new Coords(1, 3));
        assertTrue(ship.getCoords().equals(previousCoords));

        game.moveSelectedShip(new Coords(6, 19));
        assertTrue(ship.getCoords().equals(previousCoords));

        // Test that ship moves to valid coordinates and no. of moves it has left has decreased
        Coords newCoords;

        newCoords = new Coords(3, 11);
        game.moveSelectedShip(newCoords);
        assertTrue(ship.getCoords().equals(newCoords));
        assertEquals(ship.getMovesLeft(), 1);

        newCoords = new Coords(2, 12);
        game.moveSelectedShip(newCoords);
        assertTrue(ship.getCoords().equals(newCoords));
        assertEquals(ship.getMovesLeft(), 1);

        newCoords = new Coords(2, 11);
        game.moveSelectedShip(newCoords);
        assertTrue(ship.getCoords().equals(newCoords));
        assertEquals(ship.getMovesLeft(), 2);
    }

    @Test
    public void deleteShip() {
        Game game = new Game();
        Map map = new Map("Maps/32x32Maps.txt");
        Ship ship1 = new Ship(14, 1, 1, "james", 3, 1);
        Ship ship2 = new Ship(29, 7, 1, "derwent", 3, 1);
        Ship ship3 = new Ship(15, 30, 1, "vanbrugh", 3, 1);
        map.setShip(ship1);
        map.setShip(ship2);
        map.setShip(ship3);

        // Check that null is returned after searching for deleted ship
        game.deleteShip(ship1);
        assertEquals(map.getShip(new Coords(14, 1)), null);

        game.deleteShip(ship2);
        assertEquals(map.getShip(new Coords(29, 7)), null);

        game.deleteShip(ship3);
        assertEquals(map.getShip(new Coords(15, 30)), null);
    }

    @Test
    public void isShipSelected() {
        Game game = new Game();
        Ship ship = new Ship(14, 1, 1, "james", 3, 1);

        game.selectionX = 10;
        game.selectionY = 19;
        assertFalse(game.isShipSelected());

        game.selectionX = 14;
        game.selectionY = 1;
        assertTrue(game.isShipSelected());
    }

    @Test
    public void getSelectedShip() {
        Game game = new Game();
        Ship ship1 = new Ship(14, 1, 1, "james", 3, 1);
        Ship ship2 = new Ship(4, 9, 1, "james", 3, 1);

        // Set ship as selected and test the right one is picked
        game.selectionX = 14;
        game.selectionY = 1;
        assertTrue(game.getSelectedShip().equals(ship1));

        game.selectionX = 4;
        game.selectionY = 9;
        assertTrue(game.getSelectedShip().equals(ship2));
    }

    @Test
    public void getMoveSquares() {
        Game game = new Game();
        Map map = new Map("Maps/32x32Map.txt");
        Ship ship = new Ship(14, 1, 1, "james", 3, 1);

        // Set ship as selected and check correct set of squares are returned
        game.selectionX = 14;
        game.selectionY = 1;
        Set<Coords> testMoves = game.getMoveSquares();
        Set<Coords> expectedMoves = map.getPossibleMoves(ship);

        // Check that both sets contain the same moves regardless of order
        // the design of the getPossibleMoves method means the order of the moves may change
        boolean setsMatch = true;
        boolean moveMatches;
        for (Coords testMove : testMoves) {
            moveMatches = false;
            for (Coords expectedMove : expectedMoves) {
                if (testMove.equals(expectedMove)) {
                    moveMatches = true;
                }
            }
            if (!moveMatches) {
                setsMatch = false;
                break;
            }
        }
        assertTrue(setsMatch);
    }

    // These tests possibly unnecessary now? ---------

    @Test
    public void getEnemyShipCount() {
        Game game = new Game();
        game.enemyShips.add(new Ship(3, 10, 1, "derwent", 3, 1));
        game.enemyShips.add(new Ship(6, 11, 1, "derwent", 3, 1));
        game.enemyShips.add(new Ship(13, 16, 1, "vanbrugh", 3, 1));

        assertEquals(game.getEnemyShipCount("derwent"), 2);
        assertEquals(game.getEnemyShipCount("vanbrugh"), 1);
    }

    @Test
    public void createNewShips() {
        Game game = new Game();
        Map map = new Map("Maps/32x32Map.txt");

        // Check ships exist in spawning areas for each team
        game.createNewShips();

        Ship jamesShip = map.getShip(new Coords(6, 11));
        assertTrue(jamesShip != null);
        assertEquals(jamesShip.getTeam(), "james");

        Ship derwentShip = map.getShip(new Coords(24, 11));
        assertTrue(derwentShip != null);
        assertEquals(derwentShip.getTeam(), "derwent");

        Ship vanbrughShip = map.getShip(new Coords(7, 24));
        assertTrue(vanbrughShip != null);
        assertEquals(vanbrughShip.getTeam(), "vanbrugh");
    }

    @Test
    public void startNewTurn() {
        Game game = new Game();
        game.turn = 0;
        game.startNewTurn();

        for (Ship ship : game.playerShips) {
            assertEquals(ship.getMovesLeft(), 3);
            assertEquals(ship.getAttacksLeft(), 1);
        }
    }

    @Test
    public void changeTurnNum() {
        Game game = new Game();
        game.turn = 0;
        game.changeTurnNum();
        startNewTurn();
    }

    @Test
    public void hasPlayerLost() {
        Game game = new Game();
        game.playerShips.add(new Ship(1, 1, 1, "james", 3, 1));
        assertFalse(game.hasPlayerLost());

        game.playerShips.remove(0);
        assertTrue(game.hasPlayerLost());
    }

    @Test
    public void hasPlayerWon() {
        Game game = new Game();
        // Player should not have won in the initial state of the game
        assertFalse(game.hasPlayerWon());

        game.derwentCollege.setConquered(true);
        game.vanbrughCollege.setConquered(true);

        assertTrue(game.hasPlayerWon());
    }
}