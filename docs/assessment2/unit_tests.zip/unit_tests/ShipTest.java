package com.limewire.game.data;

import org.junit.Test;

import java.util.Random;

import static org.junit.Assert.*;

public class ShipTest {

    @Test
    public void nextToCoords() {
        Ship testShip = new Ship(29, 5, 1, "james", 3, 1);

        // Test against coordinates in vertical and horizontal direction that are not next to the ship
        assertFalse(testShip.nextToCoords(new Coords(27, 5)));
        assertFalse(testShip.nextToCoords(new Coords(29, 3)));
        assertFalse(testShip.nextToCoords(new Coords(31, 5)));
        assertFalse(testShip.nextToCoords(new Coords(29, 7)));

        // Test coordinates directly diagonal to the ship are not counted as next to it
        assertFalse(testShip.nextToCoords(new Coords(28, 4)));
        assertFalse(testShip.nextToCoords(new Coords(30, 4)));
        assertFalse(testShip.nextToCoords(new Coords(28, 6)));
        assertFalse(testShip.nextToCoords(new Coords(30, 6)));

        // Test random coordinates not next to the ship
        assertFalse(testShip.nextToCoords(new Coords(25, 8)));
        assertFalse(testShip.nextToCoords(new Coords(31, 16)));
        assertFalse(testShip.nextToCoords(new Coords(1, 1)));

        // Test coordinates next to ship are identified as adjacent
        assertTrue(testShip.nextToCoords(new Coords(28, 5)));
        assertTrue(testShip.nextToCoords(new Coords(30, 5)));
        assertTrue(testShip.nextToCoords(new Coords(29, 4)));
        assertTrue(testShip.nextToCoords(new Coords(29, 6)));
    }

    @Test
    public void nextToShip() {
        Ship ship1 = new Ship(29, 5, 1, "james", 3, 1);
        Ship ship2 = new Ship(27, 5, 1, "derwent", 3, 1);

        // Test ships horizontal or vertical to each other but not next to each other
        assertFalse(ship1.nextToShip(ship2));
        ship2.setX(29);
        ship2.setY(3);
        assertFalse(ship1.nextToShip(ship2));
        ship2.setX(31);
        ship2.setY(5);
        assertFalse(ship1.nextToShip(ship2));
        ship2.setX(29);
        ship2.setY(7);
        assertFalse(ship1.nextToShip(ship2));

        // Test ships directly diagonal to each other
        ship2.setX(28);
        ship2.setY(4);
        assertFalse(ship1.nextToShip(ship2));
        ship2.setX(30);
        ship2.setY(4);
        assertFalse(ship1.nextToShip(ship2));
        ship2.setX(28);
        ship2.setY(6);
        assertFalse(ship1.nextToShip(ship2));
        ship2.setX(30);
        ship2.setY(6);
        assertFalse(ship1.nextToShip(ship2));

        // Test ships adjacent to each other
        ship2.setX(28);
        ship2.setY(5);
        assertTrue(ship1.nextToShip(ship2));
        ship2.setX(30);
        ship2.setY(5);
        assertTrue(ship1.nextToShip(ship2));
        ship2.setX(29);
        ship2.setY(4);
        assertTrue(ship1.nextToShip(ship2));
        ship2.setX(29);
        ship2.setY(6);
        assertTrue(ship1.nextToShip(ship2));
    }
}