package com.limewire.game.helpers;

import com.limewire.game.data.Game;
import com.limewire.game.data.Square;
import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.*;

public class MapReaderTest {

    @Test
    public void getRawMapData() {
        MapReader mr = new MapReader();
        String[][] rawMap;
        rawMap = mr.getRawMapData("/Maps/32x32Map.txt");

        String[][] expectedMap;
        expectedMap = new String[][] {{"w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "l", "l", "w", "w", "w", "w", "w", "w", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "l", "l", "l", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "l", "l", "w", "w", "w", "w", "w", "w", "l", "w", "w", "w", "w", "l", "w", "w", "l", "l", "w", "w", "w", "l", "l", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "w", "w", "w", "w", "l", "w", "w", "w", "w", "w", "w", "l", "l", "l", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "w", "w", "w", "w", "l", "l", "l", "w", "w", "w", "l", "l", "l", "h", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "l", "l", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "w", "w", "v", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "l", "l", "w", "w", "l", "l", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "l", "l", "l", "w", "w", "w", "w", "l", "w", "w", "w", "w", "w", "w", "l", "l", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "l", "l", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "l", "l", "w", "w", "w", "w", "w", "w", "l", "l", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w", "l", "l", "l", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "w", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "l", "l", "w", "w", "w", "w", "w", "l", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "l", "w", "w", "w", "w", "w", "l", "w", "w", "l", "w", "w", "w", "w", "w", "l", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "l", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w", "l", "w", "w", "l", "w", "w", "l", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "l", "w", "w", "w", "w", "w", "l", "w", "w", "w", "w", "l", "w", "w", "l", "l", "w", "w", "w", "w", "w", "w", "w", "l", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "l", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "l", "w", "w", "w", "w", "w", "w", "w", "l", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "w", "w", "w", "w", "w", "l", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "l", "l", "l", "w", "w", "w", "w", "l", "l", "w", "w", "w", "l", "l", "l", "w", "w", "w", "w", "w", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "l", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "l", "w", "w", "w", "w", "w", "l", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "l", "l", "w", "w", "w", "w"},
                {"w", "w", "w", "l", "l", "j", "w", "w", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w", "l", "w", "w", "w", "l", "w", "w", "d", "l", "l", "l", "w", "w", "w"},
                {"w", "w", "w", "l", "l", "l", "w", "w", "w", "w", "l", "l", "l", "w", "w", "w", "l", "l", "l", "w", "w", "w", "w", "w", "w", "l", "l", "l", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "l", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "l", "l", "w", "w", "w", "w", "l", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "l", "l", "w", "w", "w", "w", "l", "w", "w", "w", "l", "w", "w", "w", "w", "w", "w", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "l", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "l", "w", "w", "w", "w", "l", "l", "w", "w", "w"},
                {"w", "w", "w", "w", "w", "l", "w", "w", "w", "w", "w", "w", "l", "l", "l", "p", "l", "l", "w", "w", "w", "w", "l", "w", "w", "w", "l", "l", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "l", "l", "l", "w", "w", "l", "w", "w", "w", "l", "l", "l", "l", "w", "w", "w", "w", "l", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "w", "w", "l", "w", "w", "l", "l", "w", "w", "w", "l", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "l", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "l", "l", "l", "w", "w", "w", "w", "w"},
                {"w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w", "w"}};

        assertTrue(Arrays.deepEquals(expectedMap, rawMap));
    }

    @Test
    public void convertMap() {
        MapReader mr = new MapReader();
        String[][] rawMap = mr.getRawMapData("/Maps/32x32Map.txt");
        Square[][] sqMap = mr.convertMap(rawMap);
        String[][] decodedSqMap = new String[Game.gridWidth][Game.gridHeight];

        // Decode sqMap elements back to string
        for (int i = 0; i < Game.gridWidth; i++) {
            for (int j = 0; j < Game.gridHeight; j++) {
                decodedSqMap[i][j] = sqMap[j][Game.gridWidth-i-1].type;
            }
        }

        assertTrue(Arrays.deepEquals(rawMap, decodedSqMap));

    }
}